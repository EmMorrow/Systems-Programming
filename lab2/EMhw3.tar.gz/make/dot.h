#include <cstdlib>
#include <vector>
#include <iostream>
#include <fstream>
#include "graph.h"

using namespace std;




// Save the graph object in a Graphviz dot file format
void save_graph(Graph &g, char *filename);